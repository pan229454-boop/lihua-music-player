梨花带雨 / 梣鬼鬼 音乐播放器 — 嵌入包

【重要】当前版本播放器不需要安装任何插件。
播放器就是一段 HTML + JS，把下面这段代码粘到网页 </body> 之前即可：

    <div id="music" api="http://你的播放器站点"></div>
    <script src="http://你的播放器站点/api/PlayerJs/id/播放器ID"></script>

把 http://你的播放器站点 换成你自己的播放器站点地址（不带结尾斜杠），
把 播放器ID 换成后台「播放器管理」里那个播放器的 ID。
播放器 ID 可以在后台播放器列表里看到（本机示例：6aef95169728b）。

保存后刷新网页就能看到悬浮播放器。

不显示时按顺序检查：
  1. 播放器 ID 是否正确；
  2. 代码是否放在 </body> 之前（不能放在 <head> 里）；
  3. 网站是否允许加载外部 JS（有些建站工具要关掉「仅允许本站脚本」）。

按钮图标显示成方框时，在 </head> 里加一行：
    <link rel="stylesheet" href="https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/font-awesome/6.0.0/css/all.min.css">

提示 jQuery 相关错误时，在 </head> 里加一行：
    <script src="https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery/3.6.0/jquery.min.js"></script>

【Emlog 安装方法（不用插件）】
1. 打开正在用的模板目录 /content/templates/你的模板/ ；
2. 编辑 footer.php，把下面的代码粘到 </body> 之前；
3. 保存后到后台「缓存管理」清理一次缓存。

说明：Emlog 官方插件站的旧地址（emlog.net/plugin/327）已经 404 打不开了，
所以这里不再依赖第三方插件，直接用上面这段代码即可。
