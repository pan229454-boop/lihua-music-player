<?php
/**
 * Plugin Name: 梨花播放器嵌入（Myhk Player）
 * Description: 在网站底部自动加载悬浮音乐播放器。免密钥，只改下面两个常量即可。
 * Version: 1.0
 * Author: 本站
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) { exit; }

/* ========= 只需改这两行 ========= */
define('MYHK_PLAYER_API', 'PUT-YOUR-PLAYER-SITE-HERE');  // 你的播放器站点，例如 http://music.example.com （不要结尾斜杠）
define('MYHK_PLAYER_ID',  '1');                          // 后台「播放器管理」列表里那个播放器的 ID
/* ================================= */

function myhk_player_ready() {
    $api = trim((string) MYHK_PLAYER_API);
    $id  = preg_replace('/[^A-Za-z0-9]/', '', (string) MYHK_PLAYER_ID);
    if ($api === '' || $api === 'PUT-YOUR-PLAYER-SITE-HERE' || stripos($api, 'http') !== 0 || $id === '') {
        return false;
    }
    return array(rtrim($api, '/'), $id);
}

function myhk_player_footer() {
    $cfg = myhk_player_ready();
    if ($cfg === false) {
        echo "\n<!-- 梨花播放器：还没配置好，请编辑 wp-content/plugins/myhk-player/myhk-player.php 顶部两行常量 -->\n";
        return;
    }
    list($api, $id) = $cfg;
    echo "\n<!-- 梨花播放器（Myhk Player） -->\n";
    echo '<div id="music" api="' . esc_url($api) . '"></div>' . "\n";
    echo '<script id="xplayer" src="' . esc_url($api . '/api/PlayerJs/id/' . $id) . '"></script>' . "\n";
}
add_action('wp_footer', 'myhk_player_footer');
